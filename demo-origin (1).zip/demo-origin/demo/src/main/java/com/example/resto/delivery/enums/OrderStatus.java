package com.example.resto.delivery.enums;

public enum OrderStatus {
    NEW,PAYED,SHIPPED,CANCELED,REFUNDED
}
