package com.example.resto.cart.enums;

public enum OrderStatus {
    NEW,PAYED,SHIPPED,CANCELED,REFUNDED
}
